package es.upm.dit.adsw.tema2.philosophers.philosophers2;

public class Chopstick {
}
